# The MIT License (MIT)
#
# Copyright (c) 2017 Niklas Rosenstein
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
"""
This example displays the orientation, pose and RSSI as well as EMG data
if it is enabled and whether the device is locked or unlocked in the
terminal.
Enable EMG streaming with double tap and disable it with finger spread.
"""

from __future__ import print_function
from myo.utils import TimeInterval

import myo
import sys
from datetime import datetime


def get_time():
    a = datetime.now()
    return "%s:%s.%s" % (a.hour, a.minute, a.microsecond)

imeFajla = '_H5_L.txt'
emgIme = 'EMG' + imeFajla
accIme = 'ACC' + imeFajla

class Listener(myo.DeviceListener):

  def __init__(self):
    self.interval = TimeInterval(None, 0.05)
    self.orientation = None
    self.gyroscope = None
    self.pose = myo.Pose.rest
    self.emg_enabled = True
    self.locked = False
    self.rssi = None
    self.emg = None
    self.mac = None

  def output(self):

    if not self.interval.check_and_reset():
      return

    parts = []
    if self.orientation:
      for comp in self.orientation:
        parts.append('{}{:.4f}'.format(' ' if comp >= 0 else '', comp))
    parts.append(str(self.pose).ljust(10))
    parts.append('E' if self.emg_enabled else ' ')
    parts.append('L' if self.locked else ' ')
    parts.append(self.rssi or 'NORSSI')
    if self.emg:
      for comp in self.emg:
        parts.append('{}{:.4f}'.format(' ' if comp >= 0 else '', comp))

    print(parts)
    sys.stdout.flush()

  def on_connected(self, event):
    event.device.request_rssi()

    event.device.stream_emg(True)

  def on_rssi(self, event):
    self.rssi = event.rssi
    #self.output()

  def on_pose(self, event):
    self.pose = event.pose
    #self.output()

  def on_orientation(self, event):
    self.orientation = event.orientation
    parts = []
    if self.orientation:
      for comp in self.orientation:
        parts.append('{}{:.4f}'.format(' ' if comp >= 0 else '', comp))
    accFile.write(str(parts) + ',' + str(get_time()) + '\n')
    # self.output()

  def on_emg(self, event):
    self.emg = event.emg
    emgFile.write(str(event.emg) + ',' + str(get_time()) + '\n')
    #self.output()

  def on_unlocked(self, event):
    self.locked = False
    #self.output()

  def on_locked(self, event):
    self.locked = True
    #self.output()




if __name__ == '__main__':
  emgFile = open(emgIme, 'w')
  accFile = open(accIme, 'w')
  myo.init(sdk_path='C:\\Users\\Jovana\\Desktop\\MYO\\myo-sdk-win-0.9.0')
  hub = myo.Hub()
  listener = Listener()
  try:
    while hub.run(listener.on_event, 500):
      #hello
    # print(datetime.datetime.now())
      pass
  except KeyboardInterrupt:
    print("Quitting...")
  finally:
    emgFile.close()
    accFile.close()

